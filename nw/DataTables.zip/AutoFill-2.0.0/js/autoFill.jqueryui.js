
$.fn.dataTable.AutoFill.classes.btn = 'ui-button ui-state-default ui-corner-all';
